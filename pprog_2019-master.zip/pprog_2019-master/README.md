# PProg2019
Iteración 3 de PProg
## Autores

- Luis Nucifora
- Víctor Perea
- Jose R.Morales
- Álvaro Platón

### Ejecución

```
make
```
```
./oca data.dat
```

### Limpiar

```
make clean
```
### Tests
